<?php

$salario = 7600.25;
$comissao = 2320.29;

$result = $salario + $comissao;
echo "Valor total a receber: R$ " . $result . "<br>";
echo "Valor total a receber: R$ " . number_format($result, 2,",",".");
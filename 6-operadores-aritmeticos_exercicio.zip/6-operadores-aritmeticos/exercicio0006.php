<?php

$salario = 7600.25;
$comissao = 1321.45;
$inss = 608.45 ;
$irrf = 1364.65 ;

$result = $salario + $comissao;
$result = $result - $inss;
$result = $result - $irrf;
echo "Valor total a receber: R$ " . $result . "<br>";
echo "Valor total a receber: R$ " . number_format($result, 2,",",".");
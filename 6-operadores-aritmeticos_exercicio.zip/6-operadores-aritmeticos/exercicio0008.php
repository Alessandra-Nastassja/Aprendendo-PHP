<?php

$preco = 280.74;
$qnt_unidade = 58;

$result = $preco * $qnt_unidade;
echo "Valor total de venda: R$ " . $result . "<br>";
echo "Valor total de venda: R$ " . number_format($result, 2,",",".");
<?php

$preco = 1220.44 ;
$num_parcela = 4;

$result = $preco / $num_parcela;
echo "Valor de cada parcela: R$ " . $result . "<br>";
echo "Valor de cada parcela: R$ " . number_format($result, 2,",",".");
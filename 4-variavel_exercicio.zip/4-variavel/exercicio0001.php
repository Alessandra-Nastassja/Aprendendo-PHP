<?php
	$nome = "Cesar";
	$sobrenome = "Szpak";
	echo "Nome: " . $nome . " " . $sobrenome;
?>
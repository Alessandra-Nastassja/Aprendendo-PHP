<?php
	$nome = "Cesar";
	$salario = 7600.25;
	$cargo = "Desenvolvedor Senior";
	echo "Nome: $nome <br>";
	echo "Salario: $salario <br>";
	echo "Nome: $cargo <br>";